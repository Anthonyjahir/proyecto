import os

class Config:
    # Clave secreta para proteger los formularios (CSRF) y las sesiones
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'clave-secreta-desarrollo'
    
    # Ruta de la base de datos SQLite (se creará automáticamente como app.db)
    SQLALCHEMY_DATABASE_URI = 'sqlite:///app.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True