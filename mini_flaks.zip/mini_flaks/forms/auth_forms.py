from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, Length, EqualTo

# Formulario para registrar un nuevo usuario
class RegisterForm(FlaskForm):
    username = StringField('Usuario', validators=[
        DataRequired(message="El usuario es obligatorio"), 
        Length(min=4, max=50, message="El usuario debe tener entre 4 y 50 caracteres")
    ])
    email = StringField('Correo Electrónico', validators=[
        DataRequired(message="El correo es obligatorio"), 
        Email(message="Debe ser un correo electrónico válido")
    ])
    password = PasswordField('Contraseña', validators=[
        DataRequired(message="La contraseña es obligatoria"), 
        Length(min=6, message="La contraseña debe tener al menos 6 caracteres")
    ])
    confirm_password = PasswordField('Confirmar Contraseña', validators=[
        DataRequired(message="Debes confirmar la contraseña"), 
        EqualTo('password', message='Las contraseñas deben coincidir')
    ])
    submit = SubmitField('Registrarse')

# Formulario para iniciar sesión
class LoginForm(FlaskForm):
    email = StringField('Correo Electrónico', validators=[
        DataRequired(message="El correo es obligatorio"), 
        Email(message="Debe ser un correo electrónico válido")
    ])
    password = PasswordField('Contraseña', validators=[
        DataRequired(message="La contraseña es obligatoria")
    ])
    submit = SubmitField('Iniciar Sesión')

# Formulario para editar el perfil del usuario
class EditProfileForm(FlaskForm):
    username = StringField('Usuario', validators=[
        DataRequired(message="El usuario es obligatorio"), 
        Length(min=4, max=50)
    ])
    email = StringField('Correo Electrónico', validators=[
        DataRequired(message="El correo es obligatorio"), 
        Email()
    ])
    submit = SubmitField('Actualizar Datos')