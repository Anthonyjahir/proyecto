from flask import Blueprint, render_template, redirect, url_for, flash, session, request
from functools import wraps
from models.user import db, User
from forms.auth_forms import RegisterForm, LoginForm, EditProfileForm

# Creamos el Blueprint para las rutas de usuario
user_bp = Blueprint('users', __name__)

# Creamos un "decorador" personalizado para proteger rutas
# Si alguien sin iniciar sesión intenta entrar a una ruta protegida, lo enviamos al login
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Por favor, inicia sesión para acceder a esta página.', 'danger')
            return redirect(url_for('users.login'))
        return f(*args, **kwargs)
    return decorated_function

# Ruta de inicio: Muestra la lista de todos los usuarios
@user_bp.route('/')
def index():
    users = User.query.all()
    return render_template('index.html', users=users)

# Ruta de Registro (GET para ver el formulario, POST para enviar los datos)
@user_bp.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    # Si el formulario se envía y los datos son válidos...
    if form.validate_on_submit():
        # Verificamos que el correo no exista ya
        if User.query.filter_by(email=form.email.data).first():
            flash('El correo ya está registrado.', 'danger')
            return redirect(url_for('users.register'))
        
        # Creamos el usuario, guardamos la contraseña cifrada y lo subimos a la BD
        new_user = User(username=form.username.data, email=form.email.data)
        new_user.set_password(form.password.data)
        
        db.session.add(new_user)
        db.session.commit()
        flash('Registro exitoso. Ahora puedes iniciar sesión.', 'success')
        return redirect(url_for('users.login'))
        
    return render_template('register.html', form=form)

# Ruta de Inicio de sesión
@user_bp.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        # Buscamos al usuario por correo
        user = User.query.filter_by(email=form.email.data).first()
        # Si el usuario existe y la contraseña es correcta...
        if user and user.check_password(form.password.data):
            # Guardamos sus datos en la sesión del navegador
            session['user_id'] = user.id
            session['username'] = user.username
            flash(f'Bienvenido, {user.username}.', 'success')
            return redirect(url_for('users.index'))
        else:
            flash('Correo o contraseña incorrectos.', 'danger')
    return render_template('login.html', form=form)

# Ruta para Cerrar sesión
@user_bp.route('/logout')
def logout():
    session.clear() # Borramos los datos de la sesión
    flash('Has cerrado sesión correctamente.', 'info')
    return redirect(url_for('users.index'))

# Ruta para ver el Perfil (Protegida)
@user_bp.route('/profile/<int:id>')
@login_required
def profile(id):
    # Buscamos al usuario por su ID, si no existe da error 404
    user = User.query.get_or_404(id)
    return render_template('profile.html', user=user)

# Ruta para Editar el Perfil (Protegida)
@user_bp.route('/profile/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_profile(id):
    user = User.query.get_or_404(id)
    
    # Evitamos que alguien edite el perfil de otro usuario
    if session.get('user_id') != user.id:
        flash('No tienes permiso para editar este perfil.', 'danger')
        return redirect(url_for('users.index'))

    # Llenamos el formulario con los datos actuales del usuario
    form = EditProfileForm(obj=user)
    if form.validate_on_submit():
        user.username = form.username.data
        user.email = form.email.data
        db.session.commit()
        flash('Perfil actualizado con éxito.', 'success')
        return redirect(url_for('users.profile', id=user.id))
        
    return render_template('edit_profile.html', form=form, user=user)

# Ruta para Eliminar el Perfil (Protegida)
@user_bp.route('/profile/<int:id>/delete', methods=['POST'])
@login_required
def delete_profile(id):
    user = User.query.get_or_404(id)
    
    if session.get('user_id') != user.id:
        flash('No tienes permiso para eliminar este perfil.', 'danger')
        return redirect(url_for('users.index'))
        
    db.session.delete(user)
    db.session.commit()
    session.clear()
    flash('Tu cuenta ha sido eliminada permanentemente.', 'info')
    return redirect(url_for('users.index'))