from flask import Flask
from config import Config
from models.user import db
from routes.user_routes import user_bp
from flask_wtf.csrf import CSRFProtect

def create_app():
    # Inicializamos la aplicación Flask
    app = Flask(__name__)
    
    # Le cargamos la configuración que creamos en el Paso 2
    app.config.from_object(Config)

    # Inicializamos las extensiones con nuestra app
    db.init_app(app)
    CSRFProtect(app)  # Esto exige que todos los formularios tengan un token de seguridad

    # Registramos el Blueprint (las rutas que hicimos en el Paso 4)
    app.register_blueprint(user_bp)

    # Este bloque crea el archivo app.db y las tablas si no existen aún
    with app.app_context():
        db.create_all()

    return app

if __name__ == '__main__':
    app = create_app()
    # Ejecutamos en modo debug para ver los errores en pantalla mientras desarrollamos
    app.run(debug=True)