from flask import Flask
from config import Config
from models.user import db
from routes.user_routes import user_bp
from flask_wtf.csrf import CSRFProtect
from flask_login import login_required

def create_app():
    # Inicializamos la aplicación Flask
    app = Flask(__name__)
    
    # Le cargamos la configuración
    app.config.from_object(Config)

    # Inicializamos las extensiones
    db.init_app(app)
    CSRFProtect(app)

    # Registramos el Blueprint
    app.register_blueprint(user_bp)

    # Ruta protegida directa para la prueba
    @app.route('/profile')
    @login_required
    def profile():
        return "Este es tu perfil protegido."

    # Crea las tablas si no existen
    with app.app_context():
        db.create_all()

    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)